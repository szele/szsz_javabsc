package pendrives;

class Main {

    public static void main(String[] args) {

        new Pendrive("Sandisk", 16, 1360 );
        new Pendrive("kingston", 32, 3190 );
        new Pendrive("Noname", 64, 6450 );
        new Pendrive("Adata", 32, 2800 );
        new Pendrive("Cruizer", 8, 1290 );
        pendrives bestPendrives;

    }

}
