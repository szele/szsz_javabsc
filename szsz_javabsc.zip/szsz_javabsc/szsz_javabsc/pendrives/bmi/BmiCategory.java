package methodstructure.bmi;

public enum BmiCategory {
    UNDERWEIGHT, OVERWEIGHT, NORMAL
}
